/* -----------------------------------------------------------------------
BASE de DONNEES : Parfum
Version : 1.0
Auteur : Mario CATALDI
Date création : 18/1/2023
------------------------------------------------------------------------- */
/* Essai de BD SQL.*/



drop schema if exists entrepotParfum cascade;
create schema entrepotParfum;


drop table if exists entrepotParfum.parfum Cascade;


CREATE TABLE entrepotParfum.parfum ( 
	id serial, 
	nom varchar, 
	marque varchar,    
	couleur varchar,
	taille int,
	prix int,
	CONSTRAINT pk_parfum PRIMARY KEY (id)
	)
	;




drop table if exists entrepotParfum.client Cascade;
CREATE TABLE entrepotParfum.client ( 
	id serial,
	nom varchar,
	prenom varchar,
	adresse varchar,
	carte varchar,
	CONSTRAINT pk_client PRIMARY KEY (id)
	)
	;




drop table if exists entrepotParfum.magasin Cascade;
CREATE TABLE entrepotParfum.magasin ( 
	id serial , 
	nom varchar, 
	adresse varchar,
	ville varchar,
	region varchar,
	CONSTRAINT pk_magasin PRIMARY KEY (id)
	)
	;



drop table if exists entrepotParfum.temps Cascade;
CREATE TABLE entrepotParfum.temps ( 
	id serial,
	jour int,
	mois int,
	annee int,
	CONSTRAINT pk_temps PRIMARY KEY (id)
	)
	;





-- Création de la table vente
drop table if exists entrepotParfum.vente Cascade;
CREATE TABLE entrepotParfum.vente ( 
	id_client serial, 
	id_magasin serial,
	id_parfum serial,
	id_temps serial,
	montant int,
	PRIMARY KEY (id_client, id_magasin, id_parfum, id_temps),
	FOREIGN KEY (id_client) REFERENCES entrepotParfum.client(id),
	FOREIGN KEY (id_magasin) REFERENCES entrepotParfum.magasin(id),
	FOREIGN KEY (id_parfum) REFERENCES entrepotParfum.parfum(id),
	FOREIGN KEY (id_temps) REFERENCES entrepotParfum.temps(id)
	)
	;
	
	

insert into entrepotParfum.parfum (id, nom, marque, couleur, taille, prix) values 
	(1, 'Sauvage', 'Dior', 'or', 30, 100),
	(2, 'N. 5', 'Chanel', 'or', 40, 80),
	(3, 'Terre', 'Hermès', 'rose', 40, 90),
	(4, 'Acqua di Gio', 'Giorgio Armani', 'or', 30, 180),
	(5, 'Sauvage', 'Dior', 'bleu', 50, 200)
	;
	

insert into entrepotParfum.client (id, nom, prenom, adresse, carte) values 
	(1, 'Mix', 'Luc', '15, rue Paris, Vincennes', '1587 1589 6957 1598 '),
	(2, 'Polaski', 'Roman', '90, rue Turgot, Saint Denis', '7891 1928 3943 6324'),
	(3, 'Retil', 'Philippe', '71, rue Saint Vincent, Lyon', '5660 3497 4959 3994'),
	(4, 'Narsil', 'Marc', '56, rue Lyon, Toulouse', '4922 5648 5476 1587'),
	(5, 'Lepape', 'Michel', '23, place de la Concorde, Paris', '4650 3034 3943 1587')
	;
	

insert into entrepotParfum.magasin (id, nom, adresse, ville, region) values 
	(1, 'Le bon parfum', '15, rue de la Paix', 'Paris', 'Ile de France'),
	(2, 'L odeur', '9, rue Venice', 'Marseille', 'PACA'),
	(3, 'Cosmetique pour toi', '91, rue de Versailles', 'Saint Germain en Laye', 'Ile de France'),
	(4, 'Amour', '66, rue de Rome', 'Versaille', 'Ile de France')
	;
	

insert into entrepotParfum.temps (id, jour, mois, annee) values 
	(1, 3, 12, 2023),
	(2, 17, 4, 2023),
	(3, 16, 2, 2023),
	(4, 11, 7, 2022),
	(5, 16, 2, 2023)
	;
	

insert into entrepotParfum.vente (id_client, id_magasin, id_parfum, id_temps, montant) values 
	(1, 1, 1, 1, 100),
	(4, 2, 3, 2, 42),
	(2, 1, 3, 3, 42),
	(3, 2, 5, 4, 250),
	(4, 2, 4, 5, 200);


